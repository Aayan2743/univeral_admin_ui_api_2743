export const mockUser = {
  email: "admin@test.com",
  password: "123456",
  name: "Admin User",
  role: "admin",
};
