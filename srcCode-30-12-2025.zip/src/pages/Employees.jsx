import DashboardLayout from "../layouts/DashboardLayout";

export default function Employees() {
  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold">Employees</h1>
    </DashboardLayout>
  );
}
