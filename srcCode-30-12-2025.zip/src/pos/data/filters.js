export const categories = [
  { id: "all", name: "All", icon: "🌿" },
  { id: "hair", name: "Hair", icon: "💇" },
  { id: "skin", name: "Skin", icon: "🧴" },
  { id: "powder", name: "Powder", icon: "🌾" },
];

export const brands = [
  { id: "all", name: "All" },
  { id: "sridevi", name: "Sridevi" },
  { id: "ayur", name: "Ayur" },
  { id: "vedic", name: "Vedic" },
];
